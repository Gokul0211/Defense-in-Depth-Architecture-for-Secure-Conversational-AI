"""
L3 v4 replay engine (results.md §34.6: an implementation amendment, 2026-11-22, before any end-to-end, VAL or TEST
number). The protected-model replay shared by the DESIGN replays (l3v4_08_design_replay.py) and the TEST replays
(l3v4_05_replay.py), so both run one code path.

Settings are those of §34 / §34.2, unchanged:
- the cached nf4 Qwen3-4B-Instruct;
- system prompt "You are a helpful assistant.";
- greedy decoding, <= 200 new tokens per reply;
- every reply conditioned on the user turns and the model's own earlier replies;
- one finished conversation per output line, resumable.

Scheduling (speed only). The §34.5 root cause: the 11-21 replay kept 6 conversations together for all of their turns. By
the late turns their KV cache outgrew the 4 GB card. The Windows driver then moved the overflow to shared system memory
instead of raising out-of-memory, and a single reply took up to 300 s. Now:
- **Turn-level pool.** Every unfinished conversation waits in a pool. Each step takes the conversations with the
  shortest next prompts (as many as fit the token budget), generates ONE reply for each, and puts them back. A
  conversation is written when its last reply exists.
- **Memory budget.** A step runs if its KV cache (batch x (longest prompt + 200) tokens), its prefill activations and a
  worst-case masked-attention term fit the free memory measured after the model load, minus a margin (see `_need`).
  Batch x longest prompt also stays <= PREFILL_TOKENS.
- **Hard cap.** the per-process memory fraction (CUDA; on Apple silicon the Metal one, sentinel/core/accel.py) is set at (memory in use + free memory - a margin). An
  overflow then raises out-of-memory instead of spilling; the budget shrinks 15 % and the step is re-planned.
- **Batch 1 vs batch >= 2.** bitsandbytes decodes a single sequence with its 4-bit GEMV kernel and dequantises the
  weights for anything larger, so a batch of 2-3 can cost more per reply than one sequence alone. Running means of
  seconds per reply (batch 1) and seconds per step (batch >= 2) decide which is cheaper.
- **Lone long prompts.** A conversation whose own prompt does not fit the budget runs alone. It uses chunked prefill,
  with the cap raised to the device total: a small spill, accepted for a few long WildChat / MHJ histories.
Progress is printed per step on stdout.
"""
import json
import os
import time
from pathlib import Path
import sys

_ROOT = Path(__file__).resolve().parents[3]
if str(_ROOT) not in sys.path:                   # sentinel.core.accel, whoever runs this from wherever
    sys.path.insert(0, str(_ROOT))

SYSTEM = "You are a helpful assistant."
MAX_NEW = 200
MODEL_DIR = Path("~/.cache/sentinel/qwen3-4b-instruct-2507-nf4").expanduser()
MIB = 1 << 20
# Memory model (§34.6 addendum, 2026-11-22 15:4x, from the design run's own peaks: non-KV use 30 - 90 MiB at batch 4 - 6):
# a step of batch b, longest prompt p needs  b (p + 200) KV  +  prefill activations  +  a worst-case masked-attention
# term; it runs if that fits `avail` = free memory after the model load - MARGIN - FIXED. The first design run used a
# flat token budget with 256 + 320 MiB held back (1,405 tokens on this card), which kept batches at 2 - 3 from turn 2 on.
MARGIN = 160 * MIB          # kept free under the dedicated memory (CUDA context growth, cuBLAS workspaces)
FIXED = 40 * MIB            # a dequantised weight tile, logits and allocator slack (measured non-KV use: 30 - 60 MiB)
ACT = 48 * 1024             # prefill activation bytes per prompt token (fp16 MLP / attention temporaries, one layer;
                            # 2026-11-23 from the logged peaks: <= ~40 KiB per batch-prompt token at batch 3 - 12)
ATTN = 32 * 4 * 3           # bytes per (query, key) pair in a masked prefill: 32 heads x fp32 scores, softmax, exp. The
                            # 2026-11-23 OOM text asked for exactly batch x 32 x P x P x 4 bytes (128 MiB at 4 x 511):
                            # the padded prefill runs the math attention path, which materialises fp32 scores.
RKV = 16 * 1024             # per cached token of one layer: SDPA expands the 8 KV heads to 32 (K and V, fp16), transient
SLACK = 100 * MIB           # allocator fragmentation: up to 136 MiB at one OOM, ~50 MiB typical (batch 2 at 1,097 tokens
                            # peaked 416 MiB above the weights); rarer overshoots fall to the OOM re-plan
PREFILL_TOKENS = 4096       # batch x longest prompt in one (unchunked) batched prefill
CHUNK = 256                 # chunked prefill for a single sequence (halves the per-chunk score matrix of 2026-11-22)
CHUNK_SPLIT = 128           # split-mode prefill chunk: its fp32 scores (chunk x P x 384 B) were the peak at ~1,100 tokens
MAX_BATCH = 12
MIN_AVAIL = 200 * MIB
LONE_FRAC_MPS = 1.5         # Apple silicon: one long conversation alone may use up to 1.5 x the recommended working set
                            # (macOS can page; the CUDA lone path lifts its cap to the whole device the same way)
# Split prefill (2026-11-23): a batch whose longest prompt exceeds SPLIT_FROM tokens prefills each conversation ALONE
# (no padding, so no materialised score matrix; chunked), merges the per-conversation caches left-padded, and decodes the
# batch with the library's own generate() from that cache. Used only after scratch/rca/l3/_engine_split_check.py has
# validated it on the GPU against plain generation (SPLIT_FLAG), or when L3_ENGINE_SPLIT=1 forces it (0 forbids it).
SPLIT_FROM = 192
SPLIT_FLAG = Path(__file__).resolve().parent / "engine_split_validated.json"


def split_allowed() -> bool:
    env = os.getenv("L3_ENGINE_SPLIT", "").strip()
    if env in ("0", "1"):
        return env == "1"
    try:
        return bool(json.loads(SPLIT_FLAG.read_text(encoding="utf-8")).get("pass"))
    except (OSError, ValueError):
        return False


def read_resumable(path):
    """Finished conversations already written (a stopped append can leave a half line: it is dropped and the file
    rewritten without it). Returns {id: row}."""
    path = Path(path)
    good = []
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            try:
                good.append(json.loads(line))
            except ValueError:
                pass
        path.write_text("".join(json.dumps(g, ensure_ascii=False) + "\n" for g in good), encoding="utf-8")
    return {g["id"]: g for g in good}


def append_row(path, row):
    with Path(path).open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, ensure_ascii=False) + "\n")
        fh.flush()


class Engine:
    """Load the protected model once; run(todo, write_row) replays every conversation of `todo` (dicts with "id" and
    "turns") and calls write_row(row, replies, ms) once per finished conversation."""

    def __init__(self, log=None):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from sentinel.core import accel
        self.torch, self.ax = torch, accel
        self.dev = dev = accel.device()
        if dev not in ("cuda:0", "mps"):
            raise RuntimeError(f"the replay engine needs a GPU (CUDA or Apple silicon), found {dev}")
        # Apple silicon (2026-11-23): the exact fp16 dequantisation of the same nf4 weights (sentinel/core/nf4_to_fp16.py)
        mdir = MODEL_DIR if dev == "cuda:0" else Path(accel.fp16_dir(str(MODEL_DIR)))
        self.log = log = log or (lambda m: print(m, flush=True))
        self.tok = AutoTokenizer.from_pretrained(str(mdir))
        self.tok.padding_side = "left"
        if dev == "cuda:0":
            self.model = AutoModelForCausalLM.from_pretrained(str(mdir), device_map={"": dev},
                                                              dtype=torch.float16).eval()
        else:
            from sentinel.core.nf4_to_fp16 import load_model
            self.model = load_model(mdir, dev, torch.float16)
        self.lone_frac = 1.0 if dev == "cuda:0" else LONE_FRAC_MPS
        self.pad = self.tok.pad_token_id or self.tok.eos_token_id
        c = self.model.config
        hd = getattr(c, "head_dim", None) or c.hidden_size // c.num_attention_heads
        self.kv_bytes = 2 * c.num_hidden_layers * c.num_key_value_heads * hd * 2       # K and V, fp16
        accel.empty_cache()
        free, total = accel.mem_info(dev)
        reserved = accel.in_use(dev)
        self.total = total
        self.cap_frac = min(1.0, max(0.05, (reserved + free - MARGIN) / total))
        accel.set_fraction(self.cap_frac, dev)
        self.avail = self.avail0 = max(MIN_AVAIL, free - MARGIN - FIXED)
        self.ok_streak = 0
        self.split_ok = split_allowed()
        log(f"engine on {dev} ({mdir.name}): weights+context reserved {reserved / MIB:.0f} MiB, free {free / MIB:.0f} / {total / MIB:.0f} MiB, "
            f"cap {self.cap_frac:.3f} ({self.cap_frac * total / MIB:.0f} MiB), KV {self.kv_bytes} B/token, "
            f"budget {self.avail / MIB:.0f} MiB for KV + activations; split prefill "
            f"{'ON' if self.split_ok else 'off'}")
        self.t1 = None              # running mean, seconds per reply at batch 1
        self.tm = None              # running mean, seconds per step at batch >= 2

    # ---- prompts -------------------------------------------------------------------------------------------------
    def prompt(self, turns, replies):
        """The same messages as the §34 replay: system, then each earlier (user, own reply), then the next user turn."""
        m = [{"role": "system", "content": SYSTEM}]
        for i in range(len(replies)):
            m += [{"role": "user", "content": turns[i]}, {"role": "assistant", "content": replies[i]}]
        m.append({"role": "user", "content": turns[len(replies)]})
        return self.tok.apply_chat_template(m, tokenize=False, add_generation_prompt=True)

    def count(self, text):
        return len(self.tok(text, add_special_tokens=False)["input_ids"])

    # ---- one generation step -------------------------------------------------------------------------------------
    def _generate_split(self, enc):
        """Prefill each conversation alone over all but its last prompt token (chunked, true positions, no padding),
        merge the caches left-padded to the batch's padded length, then let generate() process the last column and
        decode -- its own logits processing, stopping and padding, unchanged."""
        torch = self.torch
        from transformers import DynamicCache
        ids, mask = enc["input_ids"], enc["attention_mask"]
        B, N = ids.shape
        lens = [int(x) for x in mask.sum(dim=1).tolist()]
        per = []
        with torch.no_grad():
            for i in range(B):
                row = ids[i, N - lens[i]:N - 1]
                c = DynamicCache()
                for a in range(0, row.shape[0], CHUNK_SPLIT):
                    part = row[a:a + CHUNK_SPLIT][None]
                    pos = torch.arange(a, a + part.shape[1], device=part.device)[None]
                    self.model(input_ids=part, position_ids=pos, past_key_values=c, use_cache=True, logits_to_keep=1)
                per.append(c)
            merged = DynamicCache()
            for li in range(len(per[0].layers)):
                k0 = per[0].layers[li].keys
                K = k0.new_zeros((B, k0.shape[1], N - 1, k0.shape[3]))
                V = k0.new_zeros((B, k0.shape[1], N - 1, k0.shape[3]))
                for i in range(B):
                    n = lens[i] - 1
                    K[i, :, N - 1 - n:] = per[i].layers[li].keys[0]
                    V[i, :, N - 1 - n:] = per[i].layers[li].values[0]
                    per[i].layers[li].keys = per[i].layers[li].values = None       # free as the merge goes
                merged.update(K, V, li)
                del K, V
            del per
            g = self.model.generate(input_ids=ids, attention_mask=mask, past_key_values=merged,
                                    max_new_tokens=MAX_NEW, do_sample=False, pad_token_id=self.pad)
        return [self.tok.decode(x, skip_special_tokens=True).strip() for x in g[:, N:]]

    def _bucket(self, enc):
        """Apple GPU (results.md §38.9): a batch's prompts, already left-padded, get more masked left pads up to a
        bucket length (sentinel/core/accel.py), so the prefill meets a few lengths instead of one per batch. Positions
        come from the mask, as for any left-padded row. A single prompt is left as it is (its chunked prefill assumes no
        padding); off Apple's GPU nothing changes."""
        n = int(enc["input_ids"].shape[1])
        if len(enc["input_ids"]) < 2 or not self.ax.shape_buckets(self.dev):
            return enc
        extra = self.ax.bucket_len(n) - n
        if not extra:
            return enc
        ids, mask = enc["input_ids"], enc["attention_mask"]
        return {"input_ids": self.torch.cat([ids.new_full((ids.shape[0], extra), self.pad), ids], 1),
                "attention_mask": self.torch.cat([mask.new_zeros((mask.shape[0], extra)), mask], 1)}

    def _generate(self, prompts, lone, split=None):
        torch = self.torch
        enc = self._bucket(self.tok(prompts, return_tensors="pt", padding=True, add_special_tokens=False).to(self.dev))
        if split is None:
            split = self._split(len(prompts), int(enc["input_ids"].shape[1]))
        if split and not lone:
            return self._generate_split(enc)
        kw = dict(max_new_tokens=MAX_NEW, do_sample=False, pad_token_id=self.pad)
        if len(prompts) == 1 and enc["input_ids"].shape[1] > CHUNK:
            kw["prefill_chunk_size"] = CHUNK                     # one sequence: no padding, positions are exact
        if lone:
            self.ax.set_fraction(self.lone_frac, self.dev)
        try:
            with torch.no_grad():
                g = self.model.generate(**enc, **kw)
        finally:
            if lone:
                self.ax.empty_cache()
                self.ax.set_fraction(self.cap_frac, self.dev)
        return [self.tok.decode(x, skip_special_tokens=True).strip() for x in g[:, enc["input_ids"].shape[1]:]]

    def _split(self, b, p):
        return getattr(self, "split_ok", False) and b >= 2 and p > SPLIT_FROM

    def _need(self, b, p):
        """Bytes a step of batch b with longest prompt p may allocate beyond the weights: the larger of the prefill
        peak (the prompt's KV, the activations of one forward, the materialised attention scores) and the decode peak
        (the KV after 200 new tokens). In split mode one conversation is prefilled at a time, in chunks, so the score
        term is CHUNK x p instead of b x p x p."""
        decode = b * (p + MAX_NEW) * (self.kv_bytes + RKV) + SLACK
        if self._split(b, p):
            prefill = b * p * self.kv_bytes + CHUNK_SPLIT * ACT + ATTN * CHUNK_SPLIT * p + p * RKV + SLACK
            return max(prefill, decode)
        chunked = b == 1 and p > CHUNK
        q = min(p, CHUNK) if chunked else p                      # query tokens in the largest prefill forward
        prefill = b * p * self.kv_bytes + b * q * ACT + b * ATTN * q * p + b * p * RKV + SLACK
        return max(prefill, decode)

    def _plan(self, pool):
        pool.sort(key=lambda s: s["plen"])
        head = pool[0]
        if self._need(1, head["plen"]) > self.avail:
            return [head], True
        batch = [head]
        for s in pool[1:]:
            b = len(batch) + 1
            if b > MAX_BATCH or b * s["plen"] > PREFILL_TOKENS or self._need(b, s["plen"]) > self.avail:
                break
            batch.append(s)
        # (removed 2026-11-23: the batch-1 preference. Measured at ~470-token prompts: 14.3 s per reply alone vs 9.8 at
        # batch 2; the step time grows with the batch at long prompts, so tm / batch was not the per-reply cost.)
        return batch, False

    def run(self, todo, write_row, checkpoint=None, every_s=120):
        """`checkpoint` (a path): the replies of conversations still in flight are saved there every `every_s`
        seconds (atomic write) and restored on the next start, so a stop loses at most that much work instead of
        every unfinished conversation (§34.6, 2026-11-22). The file is removed when the run completes."""
        torch, log = self.torch, self.log
        pool = [{"r": r, "replies": [], "ms": []} for r in todo]
        ck = Path(checkpoint) if checkpoint else None
        if ck and ck.exists():
            try:
                saved = json.loads(ck.read_text(encoding="utf-8"))
            except ValueError:
                saved = {}
            n_res = 0
            for s in pool:
                v = saved.get(s["r"]["id"])
                if v and 0 < len(v["replies"]) < len(s["r"]["turns"]) and len(v["ms"]) == len(v["replies"]):
                    s["replies"], s["ms"] = list(v["replies"]), list(v["ms"])
                    n_res += len(v["replies"])
            log(f"checkpoint: restored {n_res} replies of unfinished conversations from {ck.name}")
        last_ck = time.time()

        def save_ck():
            if not ck:
                return
            tmp = ck.with_suffix(".tmp")
            tmp.write_text(json.dumps({s["r"]["id"]: {"replies": s["replies"], "ms": s["ms"]} for s in pool if s["replies"]},
                                      ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, ck)

        for s in pool:
            s["p"] = self.prompt(s["r"]["turns"], s["replies"])
            s["plen"] = self.count(s["p"])
        n_rep = sum(len(r["turns"]) for r in todo)
        done_rep = sum(len(s["replies"]) for s in pool)
        done_conv = steps = 0
        t0 = time.time()
        while pool:
            batch, lone = self._plan(pool)
            self.ax.reset_peak(self.dev)
            s0 = time.perf_counter()
            oom = None
            try:
                outs = self._generate([s["p"] for s in batch], lone)
            except Exception as e:                                 # noqa: BLE001 -- only an out-of-memory is handled
                if self.ax.is_mps(self.dev) and self.ax.is_oom(e) and steps and ck:
                    # Apple GPU (results.md §38.9): after finished steps an out-of-memory error is the per-shape driver
                    # memory this process has piled up, not this batch: save, hand over to a fresh process
                    save_ck()
                    self.ax.recycle_exit(f"an out-of-memory error after {steps} steps "
                                         f"({str(e).splitlines()[0][:120]})", self.dev)
                if lone or not self.ax.is_oom(e):
                    raise                                          # alone, chunked, at the device total: give up loudly
                oom = str(e).splitlines()[0][:160]                 # only the text: the failed step's tensors are freed
            if oom is not None:                                    # after the except block
                self.ax.empty_cache()
                self.ok_streak = 0
                try:
                    free_now = self.ax.mem_info(self.dev)[0] / MIB
                except Exception:                                  # noqa: BLE001
                    free_now = -1
                if len(batch) > 1:
                    self.avail = max(MIN_AVAIL, int(self.avail * 0.85))
                    log(f"  OOM at batch {len(batch)} (longest {max(s['plen'] for s in batch)} tokens): budget -> "
                        f"{self.avail / MIB:.0f} MiB; free now {free_now:.0f} MiB; {oom}")
                    continue
                log(f"  OOM alone at {batch[0]['plen']} tokens: retried on the long path")
                s0 = time.perf_counter()
                outs = self._generate([batch[0]["p"]], True)
                lone = True
            dt = time.perf_counter() - s0
            if len(batch) == 1:
                self.t1 = dt if self.t1 is None else 0.7 * self.t1 + 0.3 * dt
            else:
                self.tm = dt if self.tm is None else 0.7 * self.tm + 0.3 * dt
            peak = self.ax.peak(self.dev) / MIB
            longest = max(s["plen"] for s in batch)
            for s, o in zip(batch, outs):
                s["replies"].append(o)
                s["ms"].append(round(dt * 1000 / len(batch), 1))
                if len(s["replies"]) == len(s["r"]["turns"]):
                    write_row(s["r"], s["replies"], s["ms"])
                    pool.remove(s)
                    done_conv += 1
                else:
                    s["p"] = self.prompt(s["r"]["turns"], s["replies"])
                    s["plen"] = self.count(s["p"])
            done_rep += len(batch)
            steps += 1
            self.ax.empty_cache()
            self.ok_streak += 1
            if self.ok_streak >= 8 and self.avail < self.avail0:       # an OOM can be transient (another process,
                self.avail = min(self.avail0, int(self.avail * 1.08))  # fragmentation): win the budget back slowly
                self.ok_streak = 0
                log(f"  budget recovering -> {self.avail / MIB:.0f} MiB")
            if ck and time.time() - last_ck >= every_s:
                save_ck()
                last_ck = time.time()
            log(f"step {steps}: batch {len(batch)}{' lone' if lone else ''}, longest {longest} tok, {dt:.1f} s "
                f"({dt / len(batch):.1f} s/reply), peak {peak:.0f} MiB | {done_rep}/{n_rep} replies, "
                f"{done_conv}/{len(todo)} conversations, {time.time() - t0:.0f} s"
                + (f", driver {self.ax.driver_memory(self.dev) / MIB:.0f} MiB" if self.ax.is_mps(self.dev) else ""))
            if ck and pool and self.ax.recycle_due(self.dev, steps):
                save_ck()                                          # finished conversations are already written
                self.ax.recycle_exit(f"{steps} steps, {done_rep}/{n_rep} replies", self.dev)
        if ck and ck.exists():
            ck.unlink()
        return done_conv
