"""
L3 v4.1 (results.md §34.2), GPU: the L3 reply signal and the probe timing for every replayed conversation.
  reply  the v6 c_stack probe (scratch/rca/l1h/v6_probe.npz, exported to a scratch artifact by v6_05_export.py --out) on
         every (user turn, reply) of the TEST replays (l3v4_replay.jsonl) and the DESIGN replays (l3v4_replay_design.jsonl),
         through the PRODUCTION pair read (harm_local.pair_features + harm_score_pair)
  probe  for the DESIGN replays only: the selected L3 probe (l3v4_probe.npz) on every user-turn PREFIX, the production
         read of l3v4_02_feat.py (LocalJudge.read, early exit after layer 24, layers 16 / 20 / 24) -- the TEST prefixes are
         already featurised by the L3 chain
Resumable (partial results saved every 25 conversations). Writes scratch/rca/l3/l3v4_reply_l3.json
{id: {"reply": [score per turn], "ms": [...], "probe": [score per prefix] (design only)}}.
Run: HF_HUB_OFFLINE=1 .venv-gpu/Scripts/python.exe -B -X utf8 scratch/rca/l3/l3v4_09_reply_l3.py
"""
import json
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "scratch/rca/l3"))
D = ROOT / "scratch/rca/l3"
OUT = D / "l3v4_reply_l3.json"
ART = D / "l3_reply_artifact.npz"
from l3v4_02_feat import LAYERS, render  # noqa: E402  (the probe's production read, unchanged)


def _save(out):
    """Atomic checkpoint: a stopped write never leaves half a file."""
    import os
    tmp = OUT.with_suffix(".tmp")
    tmp.write_text(json.dumps(out), encoding="utf-8")
    os.replace(tmp, OUT)


def rows(f):
    p = D / f
    return [json.loads(line) for line in p.read_text(encoding="utf-8").splitlines() if line.strip()] if p.exists() else []


def main():
    subprocess.run([sys.executable, "-I", "-X", "utf8", str(ROOT / "scratch/rca/l1h/v6_05_export.py"), "--out", str(ART)], check=True)
    from sentinel.core import local_judge as lj
    from sentinel.layers.layer5_output import harm_local as hl
    art = hl.load_harm_artifact(ART)
    pw = np.load(D / "l3v4_probe.npz")
    test, design = rows("l3v4_replay.jsonl"), rows("l3v4_replay_design.jsonl")
    design = design + rows("l3v42_replay_val.jsonl")      # v4.2 fresh VAL (§34.8): probe + reply, as design rows
    out = json.loads(OUT.read_text(encoding="utf-8")) if OUT.exists() else {}
    todo = [(r, False) for r in test if r["id"] not in out] + [(r, True) for r in design if r["id"] not in out]
    print(f"reply / probe scoring: {len(test)} TEST + {len(design)} design conversations, {len(todo)} to go", flush=True)
    if not todo:
        return
    j = lj.get_local_judge()
    if j is None:
        raise SystemExit("no local judge")
    t0 = time.time()
    with lj._lock:
        hl.register_pair(j)
        hl.pair_features(j, "warm-up", "warm-up")
        for n, (r, is_design) in enumerate(todo, 1):
            rec = {"reply": [], "ms": []}
            for u, a in zip(r["turns"], r["replies"]):
                s = time.perf_counter()
                rec["reply"].append(hl.harm_score_pair(art, hl.pair_features(j, u, a)))
                rec["ms"].append(round((time.perf_counter() - s) * 1000, 1))
            if is_design:
                ps = []
                for k in range(1, len(r["turns"]) + 1):
                    res = j.read(render(r["turns"], k), stop_after_layer=max(LAYERS), hidden_layers=LAYERS)
                    # exactly as l3v4_02_feat stores it (fp16) and l3v4_07_test scores it
                    x = np.stack([res["hidden"][L] for L in LAYERS]).astype(np.float16).astype(np.float32).reshape(1, -1)
                    ps.append(float((((x - pw["mu"]) / pw["sd"]) @ pw["coef"][0])[0] + pw["intercept"][0]))
                rec["probe"] = ps
            out[r["id"]] = rec
            if n % 25 == 0:
                _save(out)
                print(f"  {n}/{len(todo)} {time.time() - t0:.0f} s", flush=True)
            from sentinel.core import accel                  # Apple GPU: hand over to a fresh process (results.md §38.9)
            if accel.recycle_due(j.dev, n):
                _save(out)
                accel.recycle_exit(f"{n} / {len(todo)} conversations", j.dev)
    _save(out)
    print("done", len(out), flush=True)


if __name__ == "__main__":
    main()
